<?php echo $__env->make('seller.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('seller-templete'); ?>
<?php echo $__env->make('seller.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Ahmed Raza Work\backend projects\news-dashboard\resources\views/seller/layout/main.blade.php ENDPATH**/ ?>